package net.sf.extjwnl.data.list;

import net.sf.extjwnl.util.DeepCloneable;

/**
 * A node in a list.
 *
 * @author John Didion (jdidion@didion.net)
 */
public interface Node extends DeepCloneable {
}