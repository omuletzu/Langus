/**
 * Implementations of <code>DictionaryElementFactory</code> for Princeton's release of WordNet.
 *
 * @author John Didion (jdidion@didion.net)
 * @author <a href="http://autayeu.com/">Aliaksandr Autayeu</a>
 */
package net.sf.extjwnl.princeton.data;